cat("Run the following command to load the Wolverine data:
WolverineHabitat<-raster::raster(system.file('external/WolvHabitat_Bitterroot.tif', package='rSPACE'))
\n \n")