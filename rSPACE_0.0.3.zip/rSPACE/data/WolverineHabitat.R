cat("To load data, run the following command in the R console:
WolverineHabitat<-raster::raster(system.file('external/WolvHabitat_Bitterroot.tif', package='rSPACE'))\n")